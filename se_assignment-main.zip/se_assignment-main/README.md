# se_assignment
## Software Engineering Assignment ##
Our work is to provide a **online** menu with **real-life** services.

### _web_
This folder contains the code for implementing the web based application, which is the final products for this project.

### Requirements
This folder contains the requirements that our group have discussed to successfully build the application, also to meet the customer's demands.

### System modelling
This folder contains some models which specify the work of our desired system.

### Architecture design
The design that our application will work on.

_It is still loading..._
